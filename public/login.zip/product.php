<?php
include "../../config/config.php";
session_start();
error_reporting(0);

include 'includes/header.php';  

$pid=$_GET['id'];//product ID
$cid=$_GET['cid'];//product category ID

?>

 <!-- site__body -->
 <div class="site__body">
        <div class="page-header">
          <div class="page-header__container container">
            <div class="page-header__breadcrumb">
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                    <a href="index.php">Home</a>
                    <svg class="breadcrumb-arrow" width="6px" height="9px">
                      <use
                        xlink:href="images/sprite.svg#arrow-rounded-right-6x9"
                      ></use>
                    </svg>
                  </li>
                  <li class="breadcrumb-item">
                    <a href="#">Product</a>
                    <svg class="breadcrumb-arrow" width="6px" height="9px">
                      <use
                        xlink:href="images/sprite.svg#arrow-rounded-right-6x9"
                      ></use>
                    </svg>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">
				  <?php 

$product_query="SELECT * FROM products WHERE product_id='$pid' "  ;
$result=mysqli_query($con,$product_query);
if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
    $product_id=$row['product_id'];
    $product_cat_id=$row['product_cat_id'];
    $product_brand_id=$row['product_brand_id'];
    $product_title=$row['product_title'];

?>
                 <?php echo $product_title; ?>

					<?php }}?>
                  </li>
                </ol>
              </nav>
            </div>
          </div>
        </div>
        <div class="block">
          <div class="container">
            <div
              class="product product--layout--columnar"
              data-layout="columnar"
            >
			<?php 

$product_query="SELECT * FROM products WHERE product_id='$pid' "  ;
$result=mysqli_query($con,$product_query);

if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){

    $product_id=$row['product_id'];
    $product_cat_id=$row['product_cat_id'];
    $product_brand_id=$row['product_brand_id'];
    $product_title=$row['product_title'];
    $product_price=$row['product_price'];
    $product_desc=$row['product_desc'];
    $product_image=$row['product_image'];
    $product_keywords=$row['product_keywords'];
	$product_availability=$row['availability'];

?>
		
              <div class="product__content">
                <!-- .product__gallery -->
                <div class="product__gallery">
                  <div class="product-gallery">
                    <div class="product-gallery__featured">
					<div class="owl-carousel" id="product-image">

					<img src="../admin/uploads/<?php echo $product_image;?>" alt="" >
  </div>					
                    </div>
                    <div class="product-gallery__carousel">
					<div class="owl-carousel" id="product-carousel">
					<a href="#" class="product-gallery__carousel-item"
                          ><img
                            class="product-gallery__carousel-image"
                            src="../admin/uploads/<?php echo $product_image;?>"
                            alt=""
                          /> </a
                        >
  </div>
                    </div>
                  </div>
                </div>
                <!-- .product__gallery / end -->
				<!-- .product__info -->

				<div class="product__info">
                  <div class="product__wishlist-compare">
                   
                      <svg width="16px" height="16px">
                        <use xlink:href="images/sprite.svg#compare-16"></use>
                      </svg>
                    </button>
                  </div>
                  <h1 class="product__name">
                  <?php echo $product_title; ?>
                  </h1>
                  <div class="product__rating">
                   
                   
                  </div>
                  <div class="product__description">
                  <?php echo $product_desc; ?>
                  </div>
                 
                  <ul class="product__meta">
                    <li class="product__meta-availability">
					<?php 
                                        if($product_availability=="In Stock"){
                                            ?>
											Availability: <span class="text-success"><?php echo $product_availability; ?></span>
											<?php
                                         }else{
                                           
                                            ?>
	Availability: <span class="text-danger" style="color:#c00000;"><?php echo $product_availability; ?></span>
                                        
                                        <?php
                                         }
                                        ?>                    </li>
                    
                  </ul>
                </div>
                <!-- .product__info / end --><!-- .product__sidebar -->
				<div class="product__sidebar">
                  <div class="product__availability">
				  <?php 
                                        if($product_availability=="In Stock"){
                                            ?>
											Availability: <span class="text-success"><?php echo $product_availability; ?></span>
											<?php
                                         }else{
                                           
                                            ?>
	Availability: <span class="text-danger" style="color:#c00000;"><?php echo $product_availability; ?></span>
                                        
                                        <?php
                                         }
                                        ?>
                  </div>
                  <div class="product__prices">&#8358;<?php echo $product_price; ?></div>
                  <!-- .product__options -->
                  <form class="product__options">
                    <div class="form-group product__option">
                      <?php 
							 $cat_query="SELECT * FROM categories WHERE cat_id='$product_cat_id' ";
							 $result=mysqli_query($con,$cat_query);
							
							 if(mysqli_num_rows($result)>0){
							  while ($row=mysqli_fetch_array($result)) {
								// print_r($row);
						 
								$cat_id=$row['cat_id'];
								$cat_name=$row['cat_title'];
						 
							?>
					<label class="product__option-label">Category: <?php echo $cat_name ?></label>
							<?php }} ?>
                    </div>
                    <div class="form-group product__option">
					<?php 
							 $cat_query="SELECT * FROM brands WHERE brand_id='$product_brand_id' ";
							 $result=mysqli_query($con,$cat_query);
							
							 if(mysqli_num_rows($result)>0){
							  while ($row=mysqli_fetch_array($result)) {
								// print_r($row);
						 
								$brand_id=$row['brand_id'];
								$brand_name=$row['brand_title'];
						 
							?>
						 <label class="product__option-label">Brand: <?php echo $brand_name ?></label>
							<?php }} ?>
                     
                     
                    </div>
                    <div class="form-group product__option">
                      <label
                        class="product__option-label"
                        for="product-quantity"
                        >Quantity</label
                      >
                      <div class="product__actions">
                        <div class="product__actions-item">
                          <div class="input-number product__quantity">             
						<?php 
                                        if($product_availability=="In Stock"){
                                            ?>
                               <input id="product-quantity" class=" input-number__input  form-control form-control-lg "
                                          type="number" min="1" value="1" />
							<div class="input-number__add"></div>
                            <div class="input-number__sub"></div>
                                                <?php
                                         }else{
                                           
                                            ?>
                                        
                                        <?php
                                         }
                                        ?>  
                           
                          </div>
                        </div>
                        <div
                          class="
                            product__actions-item
                            product__actions-item--addtocart
                          "
                        >
						<?php 
                                        if($product_availability=="In Stock"){
                                            ?>
                                           <button class="btn btn-primary btn-lg" pid='<?php echo $product_id; ?>' id="product">
                            Add to cart
                          </button>
                                                <?php
                                         }else{
                                           
                                            ?>
                                        
                                        <?php
                                         }
                                        ?>  
                         
                        </div>
                        <div
                          class="
                            product__actions-item
                            product__actions-item--wishlist
                          "
                        >
                         
                        </div>
                        <div
                          class="
                            product__actions-item product__actions-item--compare
                          "
                        >
                          
                        </div>
                      </div>
                    </div>
                  </form>
                  <!-- .product__options / end -->
                </div>
                <!-- .product__end -->
				
              </div>
            </div>





<?php }?>
			</div>
		</div>
	</div>

<br>
              <!-- Related Products Starts Here -->

  <div class="block block-products block-products--layout--large-first">
                <div class="container">
                    <div class="block-header">
                        <h3 class="block-header__title">You May Also Like</h3>
                        <div class="block-header__divider"></div>
                    </div>
                    <div class="block-products__body">

                            
        
                            <div class="block-products__list"
                            >


                            <?php 
                            $pid=$_GET['id'];//product ID
                           

$product_query="SELECT * FROM products WHERE product_id !='$pid' AND product_cat_id = '$product_cat_id' 
 ORDER BY RAND() LIMIT 10"  ;
$result=mysqli_query($con,$product_query);

if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){

    $product_id=$row['product_id'];
    $product_cat_id=$row['product_cat_id'];
    $product_brand_id=$row['product_brand_id'];
    $product_title=$row['product_title'];
    $product_price=$row['product_price'];
    $product_desc=$row['product_desc'];
    $product_tag=$row['product_tag'];
	$product_availability=$row['availability'];
    $product_image=$row['product_image'];
    $product_keywords=$row['product_keywords'];
?>


<div class="block-products__list-item block-products__list-item2" ;
>
                                <div class="product-card">
                                <a href="product.php?id=<?php echo $product_id; ?>&cid=<?php echo $product_cat_id; ?>">

                                    <button class="product-card__quickview" type="button">
                                    <svg
                                            width="16px" height="16px">
                                            <use xlink:href="images/sprite.svg#quickview-16"></use>
                                        </svg> <span class="fake-svg-icon"></span></button>
  </a>
                                    <div class="product-card__badges-list">
                                        <?php 
                                        if(is_null($product_tag)){
                                            // Code Here
                                         }else{
                                           
                                            ?>
                                             <div class="product-card__badge product-card__badge--hot" style="background:#c00000;border-radius:5px;">
                                        
                                        <?php echo $product_tag; ?></div>
                                        <?php
                                         }
                                        ?>
                                       
                                    </div>
                                    <div class="product-card__image">
                                    <a href="product.php?id=<?php echo $product_id; ?>&cid=<?php echo $product_cat_id; ?>">
                                                    <img src="../admin/uploads/<?php echo $product_image; ?>" alt="<?php echo $product_title; ?>">
                                                </a>    
                                            </div>
                                    <div class="product-card__info">
                                        <div class="product-card__name">
                                        <a href="product.php?id=<?php echo $product_id; ?>&cid=<?php echo $product_cat_id; ?>">
                                                <?php echo $product_title; ?></a>
                                            </div>
                                       
                                    </div>
                                    <div class="product-card__actions">
                                       
                                        <div class="product-card__prices">&#8358; <?php echo $product_price; ?></div>
                                        <div class="product-card__buttons">
                                        <?php 
                                        if($product_availability=="In Stock"){
                                            ?>
                                            <button  pid='<?php echo $product_id; ?>' id="product"
                                                class="btn btn-primary product-card__addtocart" type="button">Add To
                                                Cart</button>
                                                <?php
                                         }else{
                                           
                                            ?>
	<span class="text-danger" style="color:#c00000;"><?php echo $product_availability; ?></span>
                                        
                                        <?php
                                         }
                                        ?>    
                                               
                                        </div>
                                    </div>
                                </div>
                            </div>
                           
                           

<?php }}?>
   
<?php }?>






                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                           


<?php
include 'includes/footer.php';   
?>
