<?php
session_start();
error_reporting(0);
include('../config/config.php');
include 'includes/header.php';   
?>
<?php 
$uname=$_SESSION['dlogin'];
$uid=$_SESSION['id'];

?>
    <!--Body Content-->
    <div id="page-content">
            <!--MainContent-->
            <div id="MainContent" class="main-content" role="main" style="padding-bottom:500px;">
                <!--Breadcrumb-->
                <div class="bredcrumbWrap" >
                    <div class="container breadcrumbs bread-crumb" >
                        <a href="index.php" title="Back to the home page">Home</a><span aria-hidden="true">›</span><span>
                        <?php 
$cid=$_GET['cid'];//product category ID
$product_query="SELECT * FROM categories WHERE cat_id='$cid' "  ;
$result=mysqli_query($con,$product_query);
if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
    $cat_id=$row['cat_id'];
    $cat_name=$row['cat_title'];
?>
                 <?php echo $cat_name; ?>

					<?php }}?>
                </span>
                    </div>
                </div>
                <!--End Breadcrumb-->
  
        
                      
<!--Collection Tab slider-->
<div class="tab-slider-product section">
        	<div class="container">
            	<div class="row">
                	<div class="col-12 col-sm-12 col-md-12 col-lg-12">
                        <div class="section-header text-center">
                            <h2 class="h2">
                                Our Catalog for 
                                <?php 
$cid=$_GET['cid'];//product category ID
$product_query="SELECT * FROM categories WHERE cat_id='$cid' "  ;
$result=mysqli_query($con,$product_query);
if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
    $cat_id=$row['cat_id'];
    $cat_name=$row['cat_title'];
?>
                 <?php echo $cat_name; ?>

					<?php }}?>
                            </h2>
                            <p>Browse through our latest products</p>
                        </div>
                        <div class="tabs-listing">
                           
                            <div class="tab_container">
                                <div id="tab1" class="tab_content grid-products">
                                    <div class="productSlider">

 <?php 
$cid=$_GET['cid'];//product category ID
$product_query="SELECT * FROM products WHERE product_cat_id='$cid' LIMIT 10"  ;
$result=mysqli_query($con,$product_query);

if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){

    $product_id=$row['product_id'];
    $product_cat_id=$row['product_cat_id'];
    $product_brand_id=$row['product_brand_id'];
    $product_title=$row['product_title'];
    $product_price=$row['product_price'];
    $product_desc=$row['product_desc'];
    $product_image=$row['product_image'];
    $product_keywords=$row['product_keywords'];
    $product_tag=$row['product_tag'];
    $product_availability=$row['availability'];


?>
                                        <div class="col-12 item">
                                         <!-- start product image -->
                                            <div class="product-image">
                                                <!-- start product image -->
                                                <a href="product.php?id=<?php echo $product_id; ?>&cid=<?php echo $product_cat_id; ?>">
                                                    <!-- image -->
                                                    <img class="primary blur-up custom-image lazyload" data-src="admin/uploads/<?php echo $product_image; ?>" src="admin/uploads/<?php echo $product_image; ?>" alt="<?php echo $product_title; ?>" title="<?php echo $product_title; ?>">
                                                    <!-- End image -->
                                                    <!-- Hover image -->
                                                    <img class="hover blur-up custom-image lazyload" data-src="admin/uploads/<?php echo $product_image; ?>" src="admin/uploads/<?php echo $product_image; ?>" alt="<?php echo $product_title; ?>" title="<?php echo $product_title; ?>">
                                                    <!-- End hover image -->
                                                    <!-- product label -->
                                                    <?php 
                                        if(is_null($product_tag)){
                                            // Code Here
                                         }else{
                                           
                                            ?>
                                      <div class="product-labels rectangular">
                                    <span class="lbl pr-label1"><?php echo $product_tag; ?></span></div>
                                        <?php } ?>
                                                <!-- End product label -->
                                                </a>
                                                <!-- end product image -->
                                                <!-- Start product button -->
                                                <?php 
                                        if($product_availability=="In Stock"){
                                            ?>
                                        <form class="variants add">
                                        <button class="btn btn-addto-cart" type="button" tabindex="0" pid='<?php echo $product_id; ?>' id="product">Add To Cart</button>
                                        </form>
                                       <?php
                                         }else{   
                                        ?>
                                     <form class="variants add">
                                     <button class="btn btn-addto-cart" style="color:#ff0000;cursor: not-allowed;" disabled><?php echo $product_availability; ?></button>
                                         </form>
                                       <?php
                                         }
                                        ?> 
                                                <div class="button-set">
                                                    <a href="product.php?id=<?php echo $product_id; ?>&cid=<?php echo $product_cat_id; ?>" title="Quick View" class="quick-view-popup quick-view" >
                                                        <i class="icon anm anm-search-plus-r"></i>
                                                    </a>
                                                </div>
                                                <!-- end product button -->
                                            </div>
                                            <!-- end product image --> 
                                            <div class="product-details text-center">
    <!-- product name -->
    <div class="product-name">
        <a class="product-title" href="product.php?id=<?php echo $product_id; ?>&cid=<?php echo $product_cat_id; ?>"><?php echo $product_title; ?></a>
    </div>
    <!-- End product name -->
    <!-- product price -->
    <div class="product-price">
        <span class="price"></span>
    </div>
    <!-- End product price -->
                                        </div>                                          

                                        </div>
                                        <!--start product details -->


                                        <?php   
}}else{

?>

<div class="col-12 item empty-wrapper">
<p>No Product Found</p>
<img src="assets/images/empty.png" class="empty">
</div>
<?php
} ?> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            	</div>    
            </div>
        </div>
        <!--Collection Tab slider-->
  



	

    
 <!--Most Viewed Products Today-->
 <div class="tab-slider-product section">
        	<div class="container">
            	<div class="row">
                	<div class="col-12 col-sm-12 col-md-12 col-lg-12">
                        <div class="section-header text-center">
                            <h2 class="h2">Most Viewed Today</h2>
                            <p>Browse through products viewed by other customers today</p>
                        </div>
                        <div class="tabs-listing">
                           
                            <div class="tab_container">
                                <div  class=" grid-products">
                                    <div class="productSlider">
<?php   
$now = date('Y-m-d');
$product_query="SELECT * FROM products WHERE date_view='$now' ORDER BY counter DESC LIMIT 10"  ;
$result=mysqli_query($con,$product_query);

if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){

    $product_id=$row['product_id'];
    $product_cat_id=$row['product_cat_id'];
    $product_brand_id=$row['product_brand_id'];
    $product_title=$row['product_title'];
    $product_price=$row['product_price'];
    $product_desc=$row['product_desc'];
    $product_image=$row['product_image'];
    $product_keywords=$row['product_keywords'];
    $product_tag=$row['product_tag'];
    $product_availability=$row['availability'];



?>
                                        <div class="col-12 item">
                                         <!-- start product image -->
                                            <div class="product-image">
                                                <!-- start product image -->
                                                <a href="product.php?id=<?php echo $product_id; ?>&cid=<?php echo $product_cat_id; ?>">
                                                    <!-- image -->
                                                    <img class="primary blur-up custom-image lazyload" data-src="admin/uploads/<?php echo $product_image; ?>" src="admin/uploads/<?php echo $product_image; ?>" alt="<?php echo $product_title; ?>" title="<?php echo $product_title; ?>">
                                                    <!-- End image -->
                                                    <!-- Hover image -->
                                                    <img class="hover blur-up custom-image lazyload" data-src="admin/uploads/<?php echo $product_image; ?>" src="admin/uploads/<?php echo $product_image; ?>" alt="<?php echo $product_title; ?>" title="<?php echo $product_title; ?>">
                                                    <!-- End hover image -->
                                                    <!-- product label -->
                                                    <?php 
                                        if(is_null($product_tag)){
                                            // Code Here
                                         }else{
                                           
                                            ?>
                                      <div class="product-labels rectangular">
                                    <span class="lbl pr-label1"><?php echo $product_tag; ?></span></div>
                                        <?php } ?>
                                                <!-- End product label -->
                                                </a>
                                                <!-- end product image -->
                                                <!-- Start product button -->
                                                <?php 
                                        if($product_availability=="In Stock"){
                                            ?>
                                        <form class="variants add">
                                        <button class="btn btn-addto-cart" type="button" tabindex="0" pid='<?php echo $product_id; ?>' id="product">Add To Cart</button>
                                        </form>
                                       <?php
                                         }else{   
                                        ?>
                                     <form class="variants add">
                                     <button class="btn btn-addto-cart" style="color:#ff0000;cursor: not-allowed;" disabled><?php echo $product_availability; ?></button>
                                         </form>
                                       <?php
                                         }
                                        ?> 
                                                <div class="button-set">
                                                    <a href="product.php?id=<?php echo $product_id; ?>&cid=<?php echo $product_cat_id; ?>" title="Quick View" class="quick-view-popup quick-view" >
                                                        <i class="icon anm anm-search-plus-r"></i>
                                                    </a>
                                                </div>
                                                <!-- end product button -->
                                            </div>
                                            <!-- end product image -->                                           
                                        </div>
                                        <?php   
}}else{ ?>


<div class="col-12 item empty-wrapper">
<p class="home-empty">No product has be viewed today</p>
<img src="assets/images/empty.png" class="empty">
</div>

<?php }?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            	</div>    
            </div>
        </div>
        <!--Most Viewed Products Today-->
      






			</div>
		</div>
	</div>


<?php
include 'includes/footer.php';   
?>
						 

                            
				